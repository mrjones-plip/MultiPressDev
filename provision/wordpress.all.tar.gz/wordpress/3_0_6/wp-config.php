<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, WordPress Language, and ABSPATH. You can find more information
 * by visiting {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'wordpress3_0_6');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'r[%5^-W{u}UY`|>z[1sYNRq9<~8=?##hx8}Wz[iAl#!bdHZ25<M[;k@s&lQT%OsY');
define('SECURE_AUTH_KEY',  '}d]eYY]3kk eur-U:MLENMEH)DRjTySH;t+%-?}9p0yqM}yA!/kKF/z}ZvST^CT;');
define('LOGGED_IN_KEY',    ' txPNQ@;k]ic`=a!TCa^l%ggrx(.%<pijUZ>Od/=|s!L:>IS+E<.Wy5FTn`Bb[i2');
define('NONCE_KEY',        'hDb%1+4r*m2?btCUJvS,hSW+/[VU=zR8<O^EdPx6Ym@zQIm*yW*WXQSa=IC`lg$u');
define('AUTH_SALT',        'T:4UJsf~_Vb8~%zse2Fs(g| [?6!m~$,RtsdU(MA/yg2M8l)P3(^.CP?+tz@95P4');
define('SECURE_AUTH_SALT', '<c{e&/&B_P*e*KNU-NM+nv*/U0P9)<:k|+2A{L|3tTH)UVZr6 X5||uH,sHsNoIF');
define('LOGGED_IN_SALT',   'ZP3_g~5H:(iiDX]Mc!iFC-&*tlRpy$,QSnmT#OcNbjZafF2PpK}N/-7>m )h$UIr');
define('NONCE_SALT',       ']-PX,85IY*a@*CpO4&L/rk]}-~3#5%MYyg(rk|_^Sjd55^<B}yx` (A<9+*$nuVc');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * WordPress Localized Language, defaults to English.
 *
 * Change this to localize WordPress.  A corresponding MO file for the chosen
 * language must be installed to wp-content/languages. For example, install
 * de.mo to wp-content/languages and set WPLANG to 'de' to enable German
 * language support.
 */
define ('WPLANG', '');

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
