<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, WordPress Language, and ABSPATH. You can find more information
 * by visiting {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'wordpress3_4_2');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'BMscS[T@Pj)4ZS{I|B+)u6,3Vx~n>3S@6s97-q4a#X`=5pg7n<uiRGB(d3v*Yi<8');
define('SECURE_AUTH_KEY',  'Q8I9YzT56/ t+~l)acVYaV8J6?vd3^w]sjlk03q_?wot*3PQYcWGSX(|O&5PEV-z');
define('LOGGED_IN_KEY',    '^jB, 0S0vBAJBcwt!-|oulX@sc>tBr:7)DY$s)$L,`fePBn!2q+F$9k,7EmkClU+');
define('NONCE_KEY',        '+g32^66Q1x]AMX_R@?~OJlTW+/RUU%ak:h/[@:nGP):+bd|n#C=F@Ko-vSd3V81s');
define('AUTH_SALT',        '}_O1)f)5J&P+%/5ohGt#>b7{_s js2%0s^RV0=rbyJ)n_rFxcV(|erG]|QF^-+Fn');
define('SECURE_AUTH_SALT', '.#GlJnxMayVo?ZwDA(l a4Fmsw(M6/!%VyA3wXHsts_~-Qc49tiuZER/B,;*=KZg');
define('LOGGED_IN_SALT',   'WGki2BTVVg3:i-k2(/u~_Pq4f~[YJSG%NzY4_-[melooFR2=$rHF~W&nFl]zqF.?');
define('NONCE_SALT',       '<}<[~e/w{s|dEWU);ZI`|]XUIcOA@N6|$}B-Q:Oi&p+-M,al-bO5@atf$D-`{yV+');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * WordPress Localized Language, defaults to English.
 *
 * Change this to localize WordPress. A corresponding MO file for the chosen
 * language must be installed to wp-content/languages. For example, install
 * de_DE.mo to wp-content/languages and set WPLANG to 'de_DE' to enable German
 * language support.
 */
define('WPLANG', '');

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
