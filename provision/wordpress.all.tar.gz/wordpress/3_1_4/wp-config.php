<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, WordPress Language, and ABSPATH. You can find more information
 * by visiting {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'wordpress3_1_4');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'u/10yoImIA*J8I2z&P/R;Zdjm,G32OpK9$ROxOBor+&6)8IAS-iNq,1F.%B+-7a&');
define('SECURE_AUTH_KEY',  'Zk^&^4xnI(ipf5ei&(BVWmY>TW|^3-55e|J,c?u-N/X()I{v4:#G+8k1BV6@CRKl');
define('LOGGED_IN_KEY',    'XwPp:y%C!p$@WN`rhmmX5Hq4T+EVj)- {jZSi_P@2{m<+A2]5k%L,na0:p(@3wNc');
define('NONCE_KEY',        '|$))7s.;^=NfG5A{[vIh:_F,u`7mP>b6#/8^*M4$9;M;vq]|$1Tuc]a-G!:4<-KF');
define('AUTH_SALT',        'znWsn8jNu)HrMb9+uClZ!T4kSY?-QN<jgat/QmRZ|Ub2&o>zY#IUso)kva$z0HE_');
define('SECURE_AUTH_SALT', 'B2A+%fE$R02^$z]QnSaWfq5a[|9H*3#%|7Pq$8PEUPqoOEKs7#M}ZYfiBWNC$?3I');
define('LOGGED_IN_SALT',   'Fs57Uc{e,!DFOu>9:}Xs9H|HG6k|v1jGRKi$gZ,OHL,;,Ez-j/YRI-FoV:Il.`|Y');
define('NONCE_SALT',       '8XHT4-[m0NaT#&MJ+_`LuAhX+eAvQzfD[c76r$1Id<Jrf]9vb|Del2x~T,!/y?Wb');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * WordPress Localized Language, defaults to English.
 *
 * Change this to localize WordPress. A corresponding MO file for the chosen
 * language must be installed to wp-content/languages. For example, install
 * de_DE.mo to wp-content/languages and set WPLANG to 'de_DE' to enable German
 * language support.
 */
define('WPLANG', '');

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
