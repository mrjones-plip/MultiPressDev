<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, WordPress Language, and ABSPATH. You can find more information
 * by visiting {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'wordpress3_3_3');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'Jd5w@mZg+<e;;+`-=*EmyJg2=Z+hIHYT8[E>IZb4368XB.D/2K0+4Y+uN=.BOYDj');
define('SECURE_AUTH_KEY',  'pKhB0{B#D;EyHsiNsY!emtY-NZ5:I9=OLSLT?*rU[YXT!hAF:i+R6i!*{99uC-E`');
define('LOGGED_IN_KEY',    ':vdxuz+_FQV7-yK%=xLA|KP-LxSluJm!oP4~WS-*5;o5&g/<:{#z7~+74[QuYW(L');
define('NONCE_KEY',        'V*L>JRWXeiK@IPO]$X3+[T+>!St$+[#|;X@i@XiIcb^z}ld-+f-(-K!cY288a4!w');
define('AUTH_SALT',        ':Q?TU|4t|)3~K>M}M`Q+U8UA Z2027Rk-(l7%5%*-s:[8UU-e;DZN#3{>WX%BtZ6');
define('SECURE_AUTH_SALT', ']Q)+|j-@vpe[6zOIBQB1KBZ!vrC|YrTgEC2a= O8@M+!YJo.he$<[+/^ajtu`N=f');
define('LOGGED_IN_SALT',   '*4CZK9]1c79Dneu4 }(UzsoG76:HB`J#6Q+oI%[.+RQ9v+ 29yU0qj)+#B(Q>kR!');
define('NONCE_SALT',       '!e@AcIU!KZ1)aqoUjG>-z^[K_Vz)DaO8JK-SL/[`5VkF[(9!7]CCLQU=0GoNpr-|');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * WordPress Localized Language, defaults to English.
 *
 * Change this to localize WordPress. A corresponding MO file for the chosen
 * language must be installed to wp-content/languages. For example, install
 * de_DE.mo to wp-content/languages and set WPLANG to 'de_DE' to enable German
 * language support.
 */
define('WPLANG', '');

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
