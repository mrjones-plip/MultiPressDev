<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, WordPress Language, and ABSPATH. You can find more information
 * by visiting {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'wordpress3_8_8');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '@YM7*Ozm$Jln.}mVWcpZ&:#,J(?p^-_%zd_]YL@1Z9w@YgbV^r&rdcvSs~4_hSm~');
define('SECURE_AUTH_KEY',  '+pkM@j[413=Id g(6Z?!}D!Jw|MzDh)!$p1IKZKE>h?fc-*M6HR$+`.)L1I./5=z');
define('LOGGED_IN_KEY',    'x;t07ABN{[y]x,KwXH&t)}q@&*4|-Gt]lw@|Ll[9z3%G)n|TfMb$=X-_aWQKj-,x');
define('NONCE_KEY',        'EnLl`Tb){[_qF0ab|9?KXrF b(58B }!Gd[KKS?`lYZ`&F-eII)+VIWAtFT)#Flm');
define('AUTH_SALT',        '(d}nagKOA?m!/W;<&@jY|^3FXT~pk+w+@F=un!,9&|*m<&4$HI-Wbihh^[to-#,P');
define('SECURE_AUTH_SALT', 'Yhsa[q#38ME3F{9AU@|xiFbfQh}1|Wwmxa9-VCAz*7%`jPK-CDNRgqG*%z](z)U|');
define('LOGGED_IN_SALT',   'O.U5COME33ZF%_.a2|Yggq3P{Nc(!43WyvI-n>+nW.;-OFB8y`s:9V4Y608hYe>5');
define('NONCE_SALT',       'e83?47r$I2LNbky-l{BHenf2o2|8*hc)0-xE#/&fe/b/0cEr#Zm}iLqa%jegD*Iq');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * WordPress Localized Language, defaults to English.
 *
 * Change this to localize WordPress. A corresponding MO file for the chosen
 * language must be installed to wp-content/languages. For example, install
 * de_DE.mo to wp-content/languages and set WPLANG to 'de_DE' to enable German
 * language support.
 */
define('WPLANG', '');

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
